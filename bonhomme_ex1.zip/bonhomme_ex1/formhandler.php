<?php
  $nom = $_POST['nom'];
  $prenom = $_POST['prenom'];

  echo "<table><tr><th>Nom</th><th>Prenom</th></tr>";
  echo "<tr><td>". $nom ."</td><td>". $prenom ."</td></tr></table>";


?>
